$.ajax({
	method: "GET",
	dataType: "json",
	url: "data/dados.json",
	success: function(data) {
		var id;

		for(var i in data.fotos) {
			id = data.fotos[i].id;

			$('#content').append('<img src="' + data.fotos[i].src + '">');
		}
	}
});